# Exercise 1 `README.md`

`pip install -r requirements.txt`
