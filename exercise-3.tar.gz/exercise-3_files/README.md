This exercise consists in performing one optimization on each of the truncated octahedron and the icosahedron.

Due to me forgetting to add `scienceplots` to the `requirements.txt` file, prior to starting this exercise, please issue

`$ pip install scienceplots`

in the command line of your virtual machine terminal (ie, on JupyterHub). Alternatively, within a Jupyter Notebook, issue

```python
!pip install scienceplots
```

in a code cell. Note the preceding `!`, which tells the interpreter to interact with the terminal!
